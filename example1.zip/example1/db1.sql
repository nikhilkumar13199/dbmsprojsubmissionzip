-- MySQL dump 10.13  Distrib 5.7.27, for Linux (x86_64)
--
-- Host: localhost    Database: db1
-- ------------------------------------------------------
-- Server version	5.7.27-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `db1`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `db1` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `db1`;

--
-- Table structure for table `applicant`
--

DROP TABLE IF EXISTS `applicant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applicant` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `boardmarks` int(11) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `eemarks` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `fathername` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `userid` bigint(20) NOT NULL,
  `year` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  CONSTRAINT `applicant_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicant`
--

LOCK TABLES `applicant` WRITE;
/*!40000 ALTER TABLE `applicant` DISABLE KEYS */;
INSERT INTO `applicant` VALUES (1,51,'El Paso',699,'jessie.pinkman@gmail.com','Kyle Pinkman','Jessie Pinkman',13,2002),(2,NULL,NULL,NULL,NULL,NULL,NULL,14,NULL),(3,91,'Sunspear',904,'oberyn.martell@gmail.com','Doran Martell','Oberyn Martell',15,1996),(4,NULL,NULL,NULL,NULL,NULL,NULL,16,NULL),(5,NULL,NULL,NULL,NULL,NULL,NULL,17,NULL),(6,NULL,NULL,NULL,NULL,NULL,NULL,18,NULL),(7,83,'Varanasi',921,'narendra.modi@gmail.com','Damodar Das Modi','Narendra Modi',19,1999),(8,87,'Perth',966,'steve.irwin@gmail.com','Percy Irwin','Steve Irwin',20,1998),(9,73,'Clubhouse',691,'minnie.mouse@gmail.com','','Minnie Mouse',21,1945),(10,98,'Pasadena',981,'howard.wolowitz@gmail.com','Sam Wolowitz','Howard Wolowitz',35,2007),(11,83,'Wisconsin',726,'debbie.marinara99@yahoo.com','Ross Marinara','Debbie Marinara',40,2007),(12,NULL,NULL,NULL,NULL,NULL,NULL,42,NULL),(13,51,'Mexico City',566,'hector.martinez','Lorenzo Martinez','Hector Martinez',43,1997),(14,61,'New York',647,'barney.stinson@nyu.edu','Barnacle Stinson','Barney Stinson',46,2001),(15,88,'Polis Massa',902,'luke.skywalker@starwars.com','Anakin Skywalker','Luke Skywalker',47,1978);
/*!40000 ALTER TABLE `applicant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `application`
--

DROP TABLE IF EXISTS `application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application` (
  `applicationno` bigint(20) NOT NULL AUTO_INCREMENT,
  `alloteddept` int(11) NOT NULL,
  `dateofapplication` tinyblob,
  `applicantrollno` bigint(20) NOT NULL,
  PRIMARY KEY (`applicationno`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application`
--

LOCK TABLES `application` WRITE;
/*!40000 ALTER TABLE `application` DISABLE KEYS */;
/*!40000 ALTER TABLE `application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company` (
  `companyid` bigint(20) NOT NULL AUTO_INCREMENT,
  `ctc` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `openings` int(11) NOT NULL,
  `profile` varchar(255) DEFAULT NULL,
  `tentativeloc` varchar(255) DEFAULT NULL,
  `year` int(11) NOT NULL,
  PRIMARY KEY (`companyid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complaint`
--

DROP TABLE IF EXISTS `complaint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `complaint` (
  `complaintid` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `hostelid` bigint(20) DEFAULT NULL,
  `roomno` int(11) DEFAULT NULL,
  `sid` bigint(20) DEFAULT NULL,
  `status` varchar(255) DEFAULT 'pending',
  `subject` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`complaintid`),
  KEY `hostelid` (`hostelid`),
  KEY `sid` (`sid`),
  CONSTRAINT `complaint_ibfk_1` FOREIGN KEY (`hostelid`) REFERENCES `hostel` (`hostelid`),
  CONSTRAINT `complaint_ibfk_2` FOREIGN KEY (`sid`) REFERENCES `student` (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complaint`
--

LOCK TABLES `complaint` WRITE;
/*!40000 ALTER TABLE `complaint` DISABLE KEYS */;
INSERT INTO `complaint` VALUES (1,NULL,1,2,10,'Resolved','Fan is not working at all'),(2,NULL,1,2,10,'Resolved','Tubelight is not working');
/*!40000 ALTER TABLE `complaint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `code` bigint(20) NOT NULL AUTO_INCREMENT,
  `dept` int(11) DEFAULT '1',
  `fees` bigint(20) DEFAULT '0',
  `name` varchar(255) DEFAULT 'coursename',
  `semoffered` int(11) DEFAULT '-1',
  PRIMARY KEY (`code`),
  KEY `dept` (`dept`),
  CONSTRAINT `course_ibfk_1` FOREIGN KEY (`dept`) REFERENCES `dept` (`deptid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,8,5000,'Phy101',1),(2,16,10000,'CSO101',0),(3,16,8000,'CSO102',1),(4,13,4000,'Society And Us',0),(5,7,2000,'CIV101',0),(6,15,3000,'Indian Constitution',1),(7,6,1500,'Material Science',1),(8,10,5500,'Taxonomy101',0),(9,6,3000,'Thermodynamics of Chemical Reactions',1),(10,8,20000,'Interstellar Physics',0);
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dept`
--

DROP TABLE IF EXISTS `dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dept` (
  `deptid` int(11) NOT NULL AUTO_INCREMENT,
  `about` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `foundingyear` int(11) DEFAULT NULL,
  `hod` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`deptid`),
  KEY `hod` (`hod`),
  CONSTRAINT `dept_ibfk_1` FOREIGN KEY (`hod`) REFERENCES `staff` (`empid`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dept`
--

LOCK TABLES `dept` WRITE;
/*!40000 ALTER TABLE `dept` DISABLE KEYS */;
INSERT INTO `dept` VALUES (1,NULL,NULL,NULL,NULL,'admin'),(2,NULL,NULL,NULL,NULL,'mech'),(3,NULL,NULL,NULL,NULL,'ee'),(4,NULL,NULL,NULL,NULL,'biomed'),(5,NULL,NULL,NULL,NULL,'biochem'),(6,NULL,NULL,NULL,NULL,'chem'),(7,NULL,NULL,NULL,NULL,'civ'),(8,NULL,NULL,NULL,NULL,'phy'),(9,NULL,NULL,NULL,NULL,'def'),(10,NULL,NULL,NULL,NULL,'eco'),(11,NULL,NULL,NULL,NULL,'hist'),(12,NULL,NULL,NULL,NULL,'anthro'),(13,NULL,NULL,NULL,NULL,'socio'),(14,NULL,NULL,NULL,NULL,'geog'),(15,NULL,NULL,NULL,NULL,'polsci'),(16,NULL,NULL,NULL,NULL,'cse');
/*!40000 ALTER TABLE `dept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrollment`
--

DROP TABLE IF EXISTS `enrollment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enrollment` (
  `code` bigint(20) NOT NULL,
  `sem` int(11) NOT NULL,
  `sid` bigint(20) NOT NULL,
  `year` int(11) NOT NULL,
  `attendance` int(11) DEFAULT '0',
  `endsem` int(11) DEFAULT '0',
  `grade` int(11) DEFAULT '-1',
  `midsem` int(11) DEFAULT '0',
  PRIMARY KEY (`code`,`sem`,`sid`,`year`),
  KEY `sid` (`sid`),
  CONSTRAINT `enrollment_ibfk_1` FOREIGN KEY (`sid`) REFERENCES `student` (`sid`),
  CONSTRAINT `enrollment_ibfk_2` FOREIGN KEY (`code`) REFERENCES `course` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollment`
--

LOCK TABLES `enrollment` WRITE;
/*!40000 ALTER TABLE `enrollment` DISABLE KEYS */;
INSERT INTO `enrollment` VALUES (1,1,3,2002,0,23,8,22),(1,1,10,2005,0,0,-1,0),(2,0,3,2002,81,21,7,15),(2,0,9,2001,0,0,-1,0),(2,0,11,2007,55,16,5,4),(3,1,3,2003,0,30,8,12),(3,1,10,2004,88,25,7,9),(4,1,9,2001,0,0,-1,0),(8,1,9,2006,92,41,10,26),(10,0,13,1977,85,40,9,18);
/*!40000 ALTER TABLE `enrollment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hostel`
--

DROP TABLE IF EXISTS `hostel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hostel` (
  `hostelid` bigint(20) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `fees` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `occupants` int(11) DEFAULT '0',
  PRIMARY KEY (`hostelid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hostel`
--

LOCK TABLES `hostel` WRITE;
/*!40000 ALTER TABLE `hostel` DISABLE KEYS */;
INSERT INTO `hostel` VALUES (1,'9th Avenue',20,25000,'Lincoln Hostel',5),(2,'Lane 1',15,30000,'Darwin Hostel',0);
/*!40000 ALTER TABLE `hostel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prereq`
--

DROP TABLE IF EXISTS `prereq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prereq` (
  `prereqcc` int(11) NOT NULL,
  `thiscc` int(11) NOT NULL,
  PRIMARY KEY (`prereqcc`,`thiscc`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prereq`
--

LOCK TABLES `prereq` WRITE;
/*!40000 ALTER TABLE `prereq` DISABLE KEYS */;
/*!40000 ALTER TABLE `prereq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `dateofsubmission` date DEFAULT NULL,
  `dept` int(11) DEFAULT NULL,
  `guideempid` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `stipend` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dept` (`dept`),
  KEY `guideempid` (`guideempid`),
  CONSTRAINT `project_ibfk_1` FOREIGN KEY (`dept`) REFERENCES `dept` (`deptid`),
  CONSTRAINT `project_ibfk_2` FOREIGN KEY (`guideempid`) REFERENCES `staff` (`empid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` VALUES (1,NULL,8,3,'Super Assymetry',5000),(2,NULL,8,3,'Dark Matter ',15000),(3,NULL,10,6,'Theory of Evolution',10000);
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectallocation`
--

DROP TABLE IF EXISTS `projectallocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectallocation` (
  `projid` bigint(20) NOT NULL,
  `sem` int(11) NOT NULL,
  `sid` bigint(20) NOT NULL,
  `year` int(11) NOT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `grade` int(11) DEFAULT '-1',
  `status` varchar(255) DEFAULT 'Pending',
  PRIMARY KEY (`projid`,`sem`,`sid`,`year`),
  KEY `sid` (`sid`),
  CONSTRAINT `projectallocation_ibfk_1` FOREIGN KEY (`sid`) REFERENCES `student` (`sid`),
  CONSTRAINT `projectallocation_ibfk_2` FOREIGN KEY (`projid`) REFERENCES `project` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectallocation`
--

LOCK TABLES `projectallocation` WRITE;
/*!40000 ALTER TABLE `projectallocation` DISABLE KEYS */;
INSERT INTO `projectallocation` VALUES (1,1,3,2002,NULL,8,'Completed'),(2,1,11,2005,NULL,-1,'Pending'),(3,1,9,2005,NULL,10,'Completed');
/*!40000 ALTER TABLE `projectallocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `residesin`
--

DROP TABLE IF EXISTS `residesin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `residesin` (
  `hostelid` bigint(20) NOT NULL,
  `roomno` int(11) NOT NULL,
  `sid` bigint(20) NOT NULL,
  PRIMARY KEY (`hostelid`,`roomno`,`sid`),
  KEY `sid` (`sid`),
  CONSTRAINT `residesin_ibfk_1` FOREIGN KEY (`sid`) REFERENCES `student` (`sid`),
  CONSTRAINT `residesin_ibfk_2` FOREIGN KEY (`hostelid`) REFERENCES `hostel` (`hostelid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `residesin`
--

LOCK TABLES `residesin` WRITE;
/*!40000 ALTER TABLE `residesin` DISABLE KEYS */;
INSERT INTO `residesin` VALUES (1,1,9),(1,2,10),(1,3,11),(1,4,12),(1,5,13);
/*!40000 ALTER TABLE `residesin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roleval`
--

DROP TABLE IF EXISTS `roleval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roleval` (
  `roleno` int(11) DEFAULT NULL,
  `rolename` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roleval`
--

LOCK TABLES `roleval` WRITE;
/*!40000 ALTER TABLE `roleval` DISABLE KEYS */;
INSERT INTO `roleval` VALUES (0,'ROLE_applicant'),(1,'ROLE_student'),(2,'ROLE_staff'),(3,'ROLE_admin');
/*!40000 ALTER TABLE `roleval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `section`
--

DROP TABLE IF EXISTS `section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `section` (
  `coursecode` bigint(20) NOT NULL,
  `sectionno` int(11) NOT NULL,
  `sem` int(11) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  PRIMARY KEY (`coursecode`,`sectionno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section`
--

LOCK TABLES `section` WRITE;
/*!40000 ALTER TABLE `section` DISABLE KEYS */;
/*!40000 ALTER TABLE `section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff` (
  `empid` bigint(20) NOT NULL AUTO_INCREMENT,
  `age` int(11) DEFAULT NULL,
  `attendance` int(11) DEFAULT '-1',
  `dept` int(11) DEFAULT NULL,
  `gender` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `reportsto` bigint(20) DEFAULT NULL,
  `userid` bigint(20) NOT NULL,
  PRIMARY KEY (`empid`),
  KEY `reportsto` (`reportsto`),
  KEY `dept` (`dept`),
  KEY `userid` (`userid`),
  CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`reportsto`) REFERENCES `staff` (`empid`),
  CONSTRAINT `staff_ibfk_2` FOREIGN KEY (`dept`) REFERENCES `dept` (`deptid`),
  CONSTRAINT `staff_ibfk_3` FOREIGN KEY (`userid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (1,33,-1,14,0,'Jesus Christ',1,32),(2,26,-1,8,0,'Rajesh Koothrapalli',1,33),(3,22,-1,8,0,'Sheldon Cooper',1,34),(4,40,-1,7,0,'Roy Smith',1,36),(5,57,-1,15,1,'Elizabeth Warren',4,41),(6,61,-1,10,0,'Charles Darwin',1,44),(7,36,-1,10,0,'Gary Millard',6,45);
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `sid` bigint(20) NOT NULL AUTO_INCREMENT,
  `age` int(11) DEFAULT '0',
  `dept` int(11) DEFAULT '0',
  `gender` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `userid` bigint(20) NOT NULL,
  PRIMARY KEY (`sid`),
  KEY `userid` (`userid`),
  CONSTRAINT `student_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (1,0,2,0,'Jessie Pinkman',13),(3,0,8,0,'Howard Wolowitz',35),(9,0,10,0,'Steve Irwin',20),(10,0,15,0,'Narendra Modi',19),(11,0,13,0,'Debbie Marinara',40),(12,0,6,0,'Hector Martinez',43),(13,0,8,0,'Luke Skywalker',47);
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tab_name`
--

DROP TABLE IF EXISTS `tab_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tab_name` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tab_name`
--

LOCK TABLES `tab_name` WRITE;
/*!40000 ALTER TABLE `tab_name` DISABLE KEYS */;
INSERT INTO `tab_name` VALUES (1,'john'),(2,'kelly'),(3,'scott'),(4,'sam'),(5,'michael'),(6,'jim'),(7,'dwight'),(8,'jake'),(9,'amy'),(10,'leonard'),(11,'howard'),(12,'kane'),(13,'bean'),(14,'Robert');
/*!40000 ALTER TABLE `tab_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teaches`
--

DROP TABLE IF EXISTS `teaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teaches` (
  `coursecode` bigint(20) NOT NULL,
  `empid` bigint(20) NOT NULL,
  `sectionno` int(11) NOT NULL,
  `sem` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `classroom` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`coursecode`,`empid`,`sectionno`,`sem`,`year`),
  KEY `empid` (`empid`),
  CONSTRAINT `teaches_ibfk_1` FOREIGN KEY (`coursecode`) REFERENCES `course` (`code`),
  CONSTRAINT `teaches_ibfk_2` FOREIGN KEY (`empid`) REFERENCES `staff` (`empid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teaches`
--

LOCK TABLES `teaches` WRITE;
/*!40000 ALTER TABLE `teaches` DISABLE KEYS */;
INSERT INTO `teaches` VALUES (1,2,1,1,2002,'Auditorium-1'),(2,3,1,0,2003,'Auditorium-1'),(3,3,1,1,2003,'Lecture Hall 1'),(5,4,1,0,2005,'Civil Department Lecture Hall 1'),(8,6,1,0,2005,'Lecture Hall 2'),(10,2,1,0,1977,'Far Far Away');
/*!40000 ALTER TABLE `teaches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `password` varchar(255) DEFAULT NULL,
  `role` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'a',1,'ned'),(2,'a',0,'jon'),(3,'$2a$10$9XvdYeZypXdSJI3oqwYaiemkbHdg6ZkhXPstrbh8usaN7kiY..fNW',3,'tywin'),(4,'$2a$10$X8isSalL2DYWUHqcKiIeE.PRuESngAE5LevSQcc.Vf4WP4qYaSUz2',0,'oberyn'),(5,'a',4,'sansa'),(6,'$2a$10$CkJDS7w9mnWz9jBN9aHO8.2t/VzUjPr.O2hASPdupnKrt9ieFjkda',1,'michael'),(7,'$2a$10$qKRA6T.7J4gYdHjFtXI5X.wLm7eZuyobW5s7NwtVn0csbpUNil6Ci',0,'nikhil'),(8,'$2a$10$amlnu/RJyVGtV56HaDBy7un08ihFUUhOH9CMZCIjJGQYa7YjUWpWK',0,'donald'),(9,'$2a$10$zuhumTQcv./6KAsVw9BZ0Ol8zAldtSEomMBnUcqJGTcRk7JPkrsz.',0,'bishop'),(10,'$2a$10$RiyeNeYxkDnZw.IllZ6m2emNck8OehEILROIkWdP/OtrhGJiPLv9y',0,'hodor'),(11,'$2a$10$A.iXW7XleFgRzfsRqKLSk.fvuICyaxdSKPgOVWw5hHZhZ2rW1Ol96',0,'walter'),(12,'$2a$10$yWrSYpFqC4kHt8RK3PiLFuwEU8fQQPl3lEVyAaYzBZhR52d4TSO76',0,'Jessie'),(13,'$2a$10$s4e/vcmazWB/eSaArZrweOeLMdaoKmXCN2VKj7nuhxFS1cp/zSony',0,'Jessie'),(14,'$2a$10$VOCKhz4wiajnPAI0h1y4SOfH46AHDTIfANj1WMWtPp6OIoC0OgN/K',0,'bronn'),(15,'$2a$10$dsmrKrCA3e3sSgEh54MHvORLQBKirN2QN3xwA.okf39uuRrtdEhDm',0,'oberyn'),(16,'$2a$10$GrrzW36i7C.YDhNyiYenheR.Eg7B/k3ow2dYc37yuTAMQV/u9fGkG',1,'Kyle'),(17,'$2a$10$IFmQ3W0j7S03iJYvveCrHOlpC9k..s3.7qYDjEjB90KEzE99qG3L2',0,'Martin'),(18,'$2a$10$4n4TwdgG1aBk7oTRi.cbkeenlQlXlg8GW9VgVqz4zF95PnP9NLmlG',0,'Jose'),(19,'$2a$10$oNkI.v3MyZXa0CM2wJ29bOq/0slkhwPibGDOXnblMFlJjGU7AqIIu',1,'Modi'),(20,'$2a$10$4UayNDvyKQs/LdwiOU6VXeLTTQo9t2LLzpOCLDlzVYAE254P7VxOG',1,'Steve'),(21,'$2a$10$Jgk6OGGQ.IQExVR/DaT07eyCpeyqVU.bG.E3JqpDZQUsbCpfWcwH2',0,'minnie'),(22,'$2a$10$.4lo2ZExmJIc8WvjbTcLXebJaFIcyoIB6FJgh/JaZfe3BLEZygv8W',2,'nash'),(23,'$2a$10$.MHziD4TCY2VzqMx/nyDCObqXcvjaSnY4HXyPhBZiNV2RjpSfJ6De',2,'richard'),(24,'$2a$10$Ts9r0ElGmcBOdtMVwvYVPuV7EmkeuTh0Dsu4yIQti99SrIgCVGIHG',2,'andrew'),(25,'$2a$10$41HT7Jd8Bo7nnBWdZnNnPeaVOupo67I7si1HklyUjEjfK.IP/Se7W',2,'price'),(26,'$2a$10$r9bMzbTlHORBK7xYsXthmO7AoQv75a95lxuKUs3IAVrMTADH2mjfG',2,'soap'),(27,'$2a$10$h3j8j3.NQHrXezZ1FoT2MuH5dkt4HlfJXqmLyu3w/dGvluUunklgu',2,'shephard'),(28,'$2a$10$g8oLedtRyP2qTcalITDiYOE7Agj8c1TmgGIckiDB0aFpM8l7zPrOi',2,'roach'),(29,'$2a$10$ZLeW.gsk709olEi6SAcQ2OTGQDoOvt6aXOpiO4hYlGPe1q6oDwpci',2,'bigmac'),(30,'$2a$10$UxmWEAmetaUIEZ/Rp3AbiuWjk6DuevaIa/Ke75ELAPIFSu/1e1o06',2,'cj'),(31,'$2a$10$ZFJSdHZEe/Zx7FqxKldBu.4mD.7B/ibdozKxYcTpnxuYKZAlXjIb6',2,'brutus'),(32,'$2a$10$tNcPK9dUdL2igUIoe5Rdz.GVMnzFc6VmP3Q3V5sAZlnE1TB9D0.Hm',2,'jesus'),(33,'$2a$10$VpVdqkC38K/DnoKpgWz9Hem4O6Q/RqlW/ONmkG0t8dYO8BMJfuO/a',2,'rajesh'),(34,'$2a$10$REbAwMWucdhS.VyXNN99x.1X0GhCg0S8TJgLGbaiKcJaQcxPOy63q',2,'sheldon'),(35,'$2a$10$13NnIZK0YRreuqAygCeby.Wp/X8zN1dbNh3YpKn0hAZ0xQsYFwUUi',1,'howard'),(36,'$2a$10$r6js/tKwfs.e8nz3NxjUVeTfxqSGxXqg1HVVj.tExGmN.vkH5ov.K',2,'roy'),(37,'$2a$10$oybeUgpEBnBXwkXQzPETNu7Tj5M8ThhYt8Mjk7RAoHHOB6321mTlu',3,'admin1'),(38,'$2a$10$VvtUJYXQkhpJHe3ua6RGmOa7AgV17u5ntDKH7mebhwgyl4EARl5A2',3,'admin2'),(40,'$2a$10$SEWGSJora7hGmV4Mp9tel.o6FDJEAPXa9JzhqeJdiwR94koXYYEMe',1,'debbie'),(41,'$2a$10$n/W5EbdqhdLpT5C2Vv/PeuVzMxHZ7lAMi0JfoEcAF2qJy07SDF9cq',2,'lizzie'),(42,'$2a$10$PletjrtABOCM8zswuhtdgO4m0OMyRjvvVW0Hi10ZSYo4v35gPbTfi',0,'hector'),(43,'$2a$10$bainP/P7GmCpSxd86tmzcutZyDDVT/Hh1ypHQYfTp98dyuHoPO3L6',1,'gus'),(44,'$2a$10$u90bN.P1KvkknY5WzkUMg.0i38gcPJh86WlLwGk6tA7z2NQZB1ShW',2,'charles'),(45,'$2a$10$CTNAFb.nkFOftDdy1gKWTe/MKP1tYDV0SefqMg/IdsXJaHjMxpCJ2',2,'gary'),(46,'$2a$10$H1YNQ0/gFKsT0.3.KzVW1OL3v17/Ueknfk9QuTM4bbZHun6ecimXS',0,'barney'),(47,'$2a$10$rcpaG214ZLBg90hbCPTSheRY1FIL4iuwqnJfc4EFES9CRCsIFRh1i',1,'luke');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`springuser`@`%`*/ /*!50003 trigger addapplicant
after insert on user
for each row begin
if ( new.role = 0 ) then
insert into applicant(userid) values(new.id);
end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`springuser`@`%`*/ /*!50003 trigger addstaff 
after insert on user
for each row begin
if ( new.role = 2 ) then
insert into staff(userid) values(new.id);
end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-14 14:30:24
