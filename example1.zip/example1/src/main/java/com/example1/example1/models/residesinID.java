package com.example1.example1.models;

import java.io.Serializable;
import java.util.Objects;

public class residesinID implements Serializable{
    private int roomno;
    private int hostelid;
    private long sid;


    public residesinID(int roomno, int hostelid, long sid) {
        this.roomno = roomno;
        this.hostelid = hostelid;
        this.sid = sid;
    }


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof residesinID)) {
            return false;
        }
        residesinID residesinID = (residesinID) o;
        return roomno == residesinID.roomno && hostelid == residesinID.hostelid && sid == residesinID.sid;
    }

    @Override
    public int hashCode() {
        return Objects.hash(roomno, hostelid, sid);
    }
    

}