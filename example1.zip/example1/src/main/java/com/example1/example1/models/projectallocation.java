package com.example1.example1.models;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@IdClass(projallocationID.class)
public class projectallocation{
    @Id
    private long projid;
    @Id
    private long sid;
    @Id
    private int year;
    @Id
    private int sem;

    @Column(columnDefinition="int default -1")
    private int grade;
    @Column
    private Date dateofcompletion;
    @Column(columnDefinition="varchar(255) default 'Pending'")
    private String status;

    public long getProjid() {
        return this.projid;
    }

    public void setProjid(long projid) {
        this.projid = projid;
    }

    public long getSid() {
        return this.sid;
    }

    public void setSid(long sid) {
        this.sid = sid;
    }

    public int getYear() {
        return this.year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getSem() {
        return this.sem;
    }

    public void setSem(int sem) {
        this.sem = sem;
    }

    public int getGrade() {
        return this.grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public Date getDateofcompletion() {
        return this.dateofcompletion;
    }

    public void setDateofcompletion(Date dateofcompletion) {
        this.dateofcompletion = dateofcompletion;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    

}