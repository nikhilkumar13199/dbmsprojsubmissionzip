package com.example1.example1.forms;

public class marksform{
    
    private int midsem=-1;
    private int endsem=-1;
    private int grade=-1;
    private int attendance=0;


    public int getMidsem() {
        return this.midsem;
    }

    public void setMidsem(int midsem) {
        this.midsem = midsem;
    }

    public int getEndsem() {
        return this.endsem;
    }

    public void setEndsem(int endsem) {
        this.endsem = endsem;
    }

    public int getGrade() {
        return this.grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public int getAttendance() {
        return this.attendance;
    }

    public void setAttendance(int attendance) {
        this.attendance = attendance;
    }
    


}