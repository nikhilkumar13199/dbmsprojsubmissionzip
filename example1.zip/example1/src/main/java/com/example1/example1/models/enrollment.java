package com.example1.example1.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@IdClass(enrollmentID.class)
public class enrollment{
    @Id
    private int code;
    @Id
    private int year;
    @Id
    private int sem;
    @Id
    private long sid;

    @Column(columnDefinition="int default -1")
    private int grade;
    @Column(columnDefinition="int default -1")
    private int midsem;
    @Column(columnDefinition="int default -1")
    private int endsem;
    @Column(columnDefinition="int default -1")
    private int attendance;


    public int getCode() {
        return this.code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public int getYear() {
        return this.year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getSem() {
        return this.sem;
    }

    public void setSem(int sem) {
        this.sem = sem;
    }

    public long getSid() {
        return this.sid;
    }

    public void setSid(long sid) {
        this.sid = sid;
    }

    public int getGrade() {
        return this.grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public int getMidsem() {
        return this.midsem;
    }

    public void setMidsem(int midsem) {
        this.midsem = midsem;
    }

    public int getEndsem() {
        return this.endsem;
    }

    public void setEndsem(int endsem) {
        this.endsem = endsem;
    }

    public int getAttendance() {
        return this.attendance;
    }

    public void setAttendance(int attendance) {
        this.attendance = attendance;
    }

    

}