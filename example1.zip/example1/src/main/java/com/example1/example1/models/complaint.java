package com.example1.example1.models;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class complaint{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column
    private long complaintid;
    @Column
    private int roomno;
    @Column
    private int hostelid;
    @Column
    private long sid;
    @Column
    private String subject;
    @Column
    private Date date;
    @Column(columnDefinition="varchar(255) default 'pending'")
    private String status;


    public long getComplaintid() {
        return this.complaintid;
    }

    public void setComplaintid(long complaintid) {
        this.complaintid = complaintid;
    }

    public int getRoomno() {
        return this.roomno;
    }

    public void setRoomno(int roomno) {
        this.roomno = roomno;
    }

    public int getHostelid() {
        return this.hostelid;
    }

    public void setHostelid(int hostelid) {
        this.hostelid = hostelid;
    }

    public long getSid() {
        return this.sid;
    }

    public void setSid(long sid) {
        this.sid = sid;
    }

    public String getSubject() {
        return this.subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Date getDate() {
        return this.date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }



}