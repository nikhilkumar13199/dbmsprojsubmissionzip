package com.example1.example1.models;

import java.time.Year;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.websocket.Decoder.Binary;

@Entity
@IdClass(teachesID.class)
public class teaches{
    @Id
    private long empid;
    @Id
    private int year;
    @Id
    private int sem;
    @Id
    private long coursecode;
    @Id
    private int sectionno;
    @Column
    private String classroom;


    public long getEmpid() {
        return this.empid;
    }

    public void setEmpid(long empid) {
        this.empid = empid;
    }

    public int getYear() {
        return this.year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getSem() {
        return this.sem;
    }

    public void setSem(int sem) {
        this.sem = sem;
    }

    public long getCoursecode() {
        return this.coursecode;
    }

    public void setCoursecode(long coursecode) {
        this.coursecode = coursecode;
    }

    public int getSectionno() {
        return this.sectionno;
    }

    public void setSectionno(int sectionno) {
        this.sectionno = sectionno;
    }

    public String getClassroom() {
        return this.classroom;
    }

    public void setClassroom(String classroom) {
        this.classroom = classroom;
    }


    


    @Override
    public String toString() {
        return "{" +
            " empid='" + getEmpid() + "'" +
            ", year='" + getYear() + "'" +
            ", sem='" + getSem() + "'" +
            ", coursecode='" + getCoursecode() + "'" +
            ", sectionno='" + getSectionno() + "'" +
            ", classroom='" + getClassroom() + "'" +
            "}";
    }

}