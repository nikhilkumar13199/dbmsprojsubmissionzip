// package com.example1.example1.repositories;

// import java.util.List;

// import com.example1.example1.models.staff;

// import org.springframework.data.jpa.repository.Query;
// import org.springframework.data.repository.CrudRepository;
// import org.springframework.stereotype.Repository;

// @Repository
// public interface staffret extends CrudRepository<staff,Long>{

//     @Query("select name from staff")
//     List<staff> findallstaff();


    
// }