package com.example1.example1.models;

import java.io.Serializable;
import java.util.Objects;

public class sectionID implements Serializable {
    private long coursecode;
    private int sectionno;


    public sectionID(long coursecode, int sectionno) {
        this.coursecode = coursecode;
        this.sectionno = sectionno;
    }


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof sectionID)) {
            return false;
        }
        sectionID sectionID = (sectionID) o;
        return coursecode == sectionID.coursecode && sectionno == sectionID.sectionno;
    }

    @Override
    public int hashCode() {
        return Objects.hash(coursecode, sectionno);
    }

}