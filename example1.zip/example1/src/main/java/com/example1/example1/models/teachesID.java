package com.example1.example1.models;

import java.io.Serializable;
import java.time.Year;
import java.util.Objects;


public class teachesID implements Serializable {
    private long empid;
    private int year;
    private int sem;
    private long coursecode;
    private int sectionno;


    public teachesID(long empid, int year, int sem, long coursecode, int sectionno) {
        this.empid = empid;
        this.year = year;
        this.sem = sem;
        this.coursecode = coursecode;
        this.sectionno = sectionno;
    }


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof teachesID)) {
            return false;
        }
        teachesID teachesID = (teachesID) o;
        return empid == teachesID.empid && Objects.equals(year, teachesID.year) && sem == teachesID.sem && coursecode == teachesID.coursecode && sectionno == teachesID.sectionno;
    }

    @Override
    public int hashCode() {
        return Objects.hash(empid, year, sem, coursecode, sectionno);
    }


}