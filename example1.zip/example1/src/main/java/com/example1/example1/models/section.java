package com.example1.example1.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Entity
@IdClass(sectionID.class)
public class section{
    @Id
    private long coursecode;
    @Id
    private int sectionno;
    
    @Column
    private int year;
    @Column
    private int sem;


    public long getCoursecode() {
        return this.coursecode;
    }

    public void setCoursecode(long coursecode) {
        this.coursecode = coursecode;
    }

    public int getSectionno() {
        return this.sectionno;
    }

    public void setSectionno(int sectionno) {
        this.sectionno = sectionno;
    }

    public int getYear() {
        return this.year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getSem() {
        return this.sem;
    }

    public void setSem(int sem) {
        this.sem = sem;
    }

    public section(long coursecode, int sectionno, int year, int sem) {
        this.coursecode = coursecode;
        this.sectionno = sectionno;
        this.year = year;
        this.sem = sem;
    }

    @Override
    public String toString() {
        return "{" +
            " coursecode='" + getCoursecode() + "'" +
            ", sectionno='" + getSectionno() + "'" +
            ", year='" + getYear() + "'" +
            ", sem='" + getSem() + "'" +
            "}";
    }

}