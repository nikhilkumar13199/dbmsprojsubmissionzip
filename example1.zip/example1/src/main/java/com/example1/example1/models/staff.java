package com.example1.example1.models;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name="staff")
public class staff{
    @Id 
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="empid")
    private long id;
    
    @Column
    @Size(min=1,max=255,message="Please enter string of lenght between 1 and 255")
    private String name;
    @Column(columnDefinition="int default null")
    private int age;
    @Column(columnDefinition="int default null")
    private int gender;
    @Column(columnDefinition="int default null")
    private int dept;
    @Column(columnDefinition="int default null")
    private long userid;

    @Column(columnDefinition="int default null")
    private int attendance;

    @Column(columnDefinition="bigint default null")
    private long reportsto;


    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return this.age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getGender() {
        return this.gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public int getDept() {
        return this.dept;
    }

    public void setDept(int dept) {
        this.dept = dept;
    }

    public long getUserid() {
        return this.userid;
    }

    public void setUserid(long userid) {
        this.userid = userid;
    }

    public int getAttendance() {
        return this.attendance;
    }

    public void setAttendance(int attendance) {
        this.attendance = attendance;
    }

    public long getReportsto() {
        return this.reportsto;
    }

    public void setReportsto(long reportsto) {
        this.reportsto = reportsto;
    }
    
   


}