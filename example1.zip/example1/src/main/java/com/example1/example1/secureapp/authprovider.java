package com.example1.example1.secureapp;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.jdbc.JdbcDaoImpl;

@Configuration
public class authprovider {
    @Bean(name = "dataSource")
    public DriverManagerDataSource dataSource()
    {
        DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
        driverManagerDataSource.setDriverClassName("com.mysql.jdbc.Driver");
        driverManagerDataSource.setUrl("jdbc:mysql://localhost:3306/db1?useSSL=false");
        driverManagerDataSource.setUsername("springuser");
        driverManagerDataSource.setPassword("ThePassword");
        return driverManagerDataSource;
    }

    @Bean(name="userDetailsService")
    public UserDetailsService userDetailsService(){
        JdbcDaoImpl jdbcImpl = new JdbcDaoImpl();
        jdbcImpl.setDataSource(dataSource());
        jdbcImpl.setUsersByUsernameQuery("select username,password,1 from user where username=?");
        jdbcImpl.setAuthoritiesByUsernameQuery("select username,rolename from user,roleval where user.role=roleval.roleno and username=?");
        return jdbcImpl;
    }
}