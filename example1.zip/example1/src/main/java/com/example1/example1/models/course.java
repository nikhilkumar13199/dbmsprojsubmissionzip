package com.example1.example1.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="course")
public class course{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long code;
    @Column(columnDefinition="varchar(255) default 'coursename'")
    public String name;
    @Column(columnDefinition="bigint default 0")
    public long fees;
    @Column(columnDefinition="int default -1")
    public int semoffered;
    @Column(columnDefinition="int default 1")
    public int dept;
    

    public long getCode() {
        return this.code;
    }

    public void setCode(long code) {
        this.code = code;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getFees() {
        return this.fees;
    }

    public void setFees(long fees) {
        this.fees = fees;
    }

    public int getSemoffered() {
        return this.semoffered;
    }

    public void setSemoffered(int semoffered) {
        this.semoffered = semoffered;
    }

    public int getDept() {
        return this.dept;
    }

    public void setDept(int dept) {
        this.dept = dept;
    }


}