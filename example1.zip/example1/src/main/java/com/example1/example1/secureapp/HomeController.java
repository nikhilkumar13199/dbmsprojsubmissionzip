package com.example1.example1.secureapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.MultiValueMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import com.example1.example1.forms.admitstudform;
import com.example1.example1.forms.assignprojform;
import com.example1.example1.forms.marksform;
import com.example1.example1.forms.projgradeform;
import com.example1.example1.forms.registerincourse;
import com.example1.example1.models.complaint;
import com.example1.example1.models.course;
import com.example1.example1.models.dept;
import com.example1.example1.models.hostel;
import com.example1.example1.models.project;
import com.example1.example1.models.staff;
import com.example1.example1.models.t1;
import com.example1.example1.models.t2;
import com.example1.example1.models.teaches;

@Controller
public class HomeController 
{
    @Autowired
	Userrepo userRepo;
	
    @RequestMapping("add")
    public ModelAndView add()
    {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
		} else {
			username = principal.toString();
		}
		User thisuser=userRepo.getUser(username);
		// if(thisuser.getRole()!=3){
		// 	return new ModelAndView("error");
		// }
		Map<Integer,String> roles=new HashMap<Integer,String>();
		roles.put(0,"applicant");
		// roles.put(1,"student");
		roles.put(2,"staff");
		roles.put(3,"admin");
		ModelAndView m= new ModelAndView("reg");
		m.addObject("roles", roles);
		m.addObject("user", new User());
		// return new ModelAndView("reg","user",new User());
		return m;
    }
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String submit(@Valid @ModelAttribute("user")User user,
                         BindingResult result, ModelMap model) {
        if (result.hasErrors()) {
            return "error";
		}
		// int allroles[]={0,1,2,3};
		// model.addAttribute("rolelist",userRepo.allroles() );
		
	
        model.addAttribute("name", user.getUsername());
        model.addAttribute("pass",user.getPassword());
		// model.addAttribute("role", user.getRole());
		BCryptPasswordEncoder b=new BCryptPasswordEncoder();
		user.setPassword(b.encode(user.getPassword()));

		userRepo.addUser(user);
		User thisuser=userRepo.getUser(user.getUsername());
		model.addAttribute("id", thisuser.getId());
		System.out.println(thisuser.getId());

        return "userview";
	}
	// @RequestMapping(value="/addstudent",method=RequestMethod.POST)
	// public String submit2(){
		
	// 	return "studentreg";
	// } 
	// @RequestMapping(value="/admitstud",method=RequestMethod.GET)
	// public String admitstudview(Model model){
	// 	model.addAttribute(new admitstudform());
	// 	return "admitstud";
	// }
	@RequestMapping(value="admitstud")
	public ModelAndView admitstud(){
		ModelAndView m=new ModelAndView("admitstud");
		Map<Long,String> applicants=new HashMap<Long,String>();
		List<t2> allapps=userRepo.getallApps();
		for(t2 x:allapps){
			applicants.put(x.getId(),x.getName());
		}
		m.addObject("allapps", applicants);
		m.addObject("admitstudform", new admitstudform());

		Map<Integer,String> depts=new HashMap<Integer,String>();
		List<dept> alldepts=userRepo.getalldept();
		for(dept x:alldepts){
			depts.put(x.getDeptid(),x.getName());
		}
		m.addObject("alldepts", depts);

		// return new ModelAndView("admitstud", "admitstudform", new admitstudform());
		return m;
	}
	@RequestMapping(value = "/admitstud", method = RequestMethod.POST)
    public String admitstudview(@Valid @ModelAttribute("admitstudform")admitstudform details,
                         BindingResult result, ModelMap model) {
        if (result.hasErrors()) {
            return "error";
		}


		
        model.addAttribute("aid", details.getAid());
		model.addAttribute("dept",details.getDept());
		userRepo.admitstudent(details);

        return "home";
	}
	@RequestMapping("/")
	public String home(Model model)
	{

		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if (principal instanceof UserDetails) {

			String username = ((UserDetails)principal).getUsername();
			model.addAttribute("username",username);

		} else {

			String username = principal.toString();
			model.addAttribute("username",username);

		}


		return "home";
	}
	
	@RequestMapping("/login")
	public String loginPage()
	{
		return "login";
	}
	
	@RequestMapping("/logout-success")
	public String logoutPage()
	{
		return "logout";
	}

	@RequestMapping("addapplicantinfo")
	public ModelAndView addapplicant(){
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
		} else {
			username = principal.toString();
		}
		User thisuser=userRepo.getUser(username);
		// if(thisuser.getRole()!=0){
		// 	return new ModelAndView("error");
		// }
		return new ModelAndView("addapplicantinfo", "applicant", new t2());
	}
	@RequestMapping(value = "/addapplicantinfo", method = RequestMethod.POST)
    public String submitapplicantinfo(@Valid @ModelAttribute("applicant")t2 a,
                         BindingResult result, ModelMap model) {
        if (result.hasErrors()) {
            return "error";
		}

		model.addAttribute("boardmarks", a.getBoardmarks());
		model.addAttribute("city", a.getCity());
		model.addAttribute("eemarks", a.getEemarks());
		model.addAttribute("email", a.getEmail());
		model.addAttribute("fathername", a.getFathername());
		model.addAttribute("name", a.getName());
		model.addAttribute("year", a.getYear());
		model.addAttribute("userid", a.getUserid());

		userRepo.addapplicantinfo(a);

        return "applicantinfo";
	}
	@RequestMapping("addstaffinfo")
	public ModelAndView addstaff(){
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
		} else {
			username = principal.toString();
		}
		User thisuser=userRepo.getUser(username);
		// if(thisuser.getRole()!=2){
		// 	return new ModelAndView("error");
		// }
		return new ModelAndView("addstaffinfo", "staff", new staff());
	}
	@RequestMapping(value = "/addstaffinfo", method = RequestMethod.POST)
    public String submitstaffinfo(@Valid @ModelAttribute("staff")staff a,
                         BindingResult result, ModelMap model) {
        if (result.hasErrors()) {
            return "error";
		}

		model.addAttribute("age", a.getAge());
		model.addAttribute("dept", a.getDept());
		model.addAttribute("gender", a.getGender());
		model.addAttribute("reportsto", a.getReportsto());
		model.addAttribute("name", a.getName());
		// model.addAttribute("userid", a.getUserid());

		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {

			username = ((UserDetails)principal).getUsername();
			// model.addAttribute("username",username);

		} else {

			username = principal.toString();
			// model.addAttribute("username",username);

		}
		User thisuser=userRepo.getUser(username);
		a.setUserid(thisuser.getId());
		model.addAttribute("userid", thisuser.getId());
		System.out.println(a.getUserid());
		System.out.println(thisuser.getRole());

		userRepo.addstaffinfo(a);

        return "staffinfo";
	}
	
	@RequestMapping(value="/addcourse")
	public ModelAndView addcourse(){
		return new ModelAndView("addcourse", "course", new course());
	}
	@RequestMapping(value = "/addcourse", method = RequestMethod.POST)
    public String addcourseinfo(@Valid @ModelAttribute("course")course a,
                         BindingResult result, ModelMap model) {
        if (result.hasErrors()) {
            return "error";
		}

		model.addAttribute("dept", a.getDept());
		model.addAttribute("fees", a.getFees());
		model.addAttribute("name", a.getName());
		model.addAttribute("semoffered", a.getSemoffered());
		
		userRepo.addcourse(a);
        return "viewaddedcourse";
	}


	@RequestMapping(value="/registerincourse")
	public ModelAndView registerincourse(){
		return new ModelAndView("registerincourse", "newregcourse", new registerincourse());
	}
	@RequestMapping(value = "/registerincourse", method = RequestMethod.POST)
    public String regnewcourse(@Valid @ModelAttribute("newregcourse")registerincourse details,
                         BindingResult result, ModelMap model) {
        if (result.hasErrors()) {
            return "error";
		}

		model.addAttribute("code", details.getCode());
		model.addAttribute("year", details.getYear());
		model.addAttribute("sem", details.getSem());

		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
		} else {
			username = principal.toString();
		}
		User thisuser=userRepo.getUser(username);
		System.out.println(thisuser.getId());
		// if(thisuser.getRole()!=1){
		// 	return "error";
		// }
		userRepo.coursereg(details,thisuser.getId(),thisuser.getRole());
		System.out.println(thisuser.getRole());
		System.out.println(thisuser.getUsername());
        return "home";
	}
	@RequestMapping("addteaches")
	public ModelAndView addteaches(){
		return new ModelAndView("addteaches", "teaches", new teaches());
	}
	@RequestMapping(value = "/addteaches", method = RequestMethod.POST)
    public String submitapplicantinfo(@Valid @ModelAttribute("teaches")teaches a,
                         BindingResult result, ModelMap model) {
        if (result.hasErrors()) {
            return "error";
		}


		// model.addAttribute("coursecode", a.getCoursecode());
		// model.addAttribute("empid", a.getEmpid());
		// model.addAttribute("sectionno", a.getSectionno());
		// model.addAttribute("sem", a.getSem());
		// model.addAttribute("year", a.getYear());
		// model.addAttribute("classroom", a.getClassroom());

		userRepo.addTeachesInstance(a);
		


        return "home";
	}
	@RequestMapping(value="viewyourstudents")
	public String viewyourstudents(Model model){
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {

			username = ((UserDetails)principal).getUsername();
			// model.addAttribute("username",username);

		} else {

			username = principal.toString();
			// model.addAttribute("username",username);

		}
		User thisuser=userRepo.getUser(username);
		System.out.println(thisuser.getId());
		model.addAttribute("all", userRepo.findenr(thisuser.getId()));
		return "viewyourstudents";
	}
	@RequestMapping(value="/viewcourses")
	public String viewcourses(Model model){
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
		} else {
			username = principal.toString();
		}
		User thisuser=userRepo.getUser(username);
		model.addAttribute("allcourses", userRepo.findAllCourses(thisuser.getId()));
		return "viewcourses";
	}
	@RequestMapping(value="/viewcourses/{courseid}")
	public String viewstudentenr (@PathVariable int courseid,Model model){
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
		} else {
			username = principal.toString();
		}
		User thisuser=userRepo.getUser(username);

		model.addAttribute("courseid",courseid);
		model.addAttribute("allstudents", userRepo.findAllStudetsEnr(courseid));
		return "viewstudentenr";
	}
	// @RequestMapping(value="viewcourses/{courseid}/{sid}")
	// public String assignmarks(@PathVariable int courseid,@PathVariable long sid,Model model){

	// 	return "assignmarks";
	// }
	@RequestMapping(value="viewcourses/{courseid}/{sid}")
	public ModelAndView assignmarks(@PathVariable int courseid,@PathVariable long sid,Model model){
		System.out.println(sid);
		System.out.println(courseid);
		System.out.println("reached here kdksndkskkkskd");
		model.addAttribute("courseid", courseid);
		model.addAttribute("sid", sid);
		return new ModelAndView("assignmarks","marksform",new marksform());
	}
	@RequestMapping(value="/viewcourses/{courseid}/{sid}",method=RequestMethod.POST)
	public String assignmarksview(@PathVariable int courseid,@PathVariable long sid,@Valid @ModelAttribute("marksform")marksform a,
	BindingResult result, ModelMap model){
		userRepo.assignmarks(courseid,sid,a);
		return "home";
	}

	@RequestMapping(value="addhostel")
	public ModelAndView addhostel(){
		return new ModelAndView("addhostel","newhostel",new hostel());
	}
	@RequestMapping(value = "/addhostel", method = RequestMethod.POST)
    public String addhostelview(@Valid @ModelAttribute("newhostel")hostel a,
                         BindingResult result, ModelMap model) {
        if (result.hasErrors()) {
            return "error";
		}


		userRepo.addhostel(a);
		


        return "home";
	}
	@RequestMapping(value="addproject")
	public ModelAndView addproj(){
		return new ModelAndView("addproj","newproj",new project());
	}
	@RequestMapping(value="/addproject",method=RequestMethod.POST)
	public String addproj(@Valid @ModelAttribute("newproj")project a,
                         BindingResult result, ModelMap model) {
        if (result.hasErrors()) {
            return "error";
		}
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
		} else {
			username = principal.toString();
		}
		User thisuser=userRepo.getUser(username);
		

		userRepo.addproj(a,thisuser.getId());
		


        return "home";
	}
	@RequestMapping(value="addcomplaint")
	public ModelAndView addcomp(){
		return new ModelAndView("addcomp","newcomp",new complaint());
	}
	@RequestMapping(value="/addcomplaint",method=RequestMethod.POST)
	public String addcomp(@Valid @ModelAttribute("newcomp")complaint a,
                         BindingResult result, ModelMap model) {
        if (result.hasErrors()) {
            return "error";
		}
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
		} else {
			username = principal.toString();
		}
		User thisuser=userRepo.getUser(username);
		
		userRepo.addcomp(thisuser.getId(),a);

        return "home";
	}
	@RequestMapping(value="/resolvecomps")
	public String rescomp(Model model){
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
		} else {
			username = principal.toString();
		}
		User thisuser=userRepo.getUser(username);
		model.addAttribute("allComps", userRepo.findallcomps());
		return "rescomps";
	}
	@RequestMapping(value="/resolvecomps/{complaintid}")
	public String statuscomp(@PathVariable long complaintid){
		userRepo.changecompstatus(complaintid);
		return "home";
	}

	@RequestMapping(value="/checkresult")
	public String checkres(Model model){
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
		} else {
			username = principal.toString();
		}
		User thisuser=userRepo.getUser(username);
		model.addAttribute("result", userRepo.getresult(thisuser.getId()));
		return "checkres";
	}

	@RequestMapping(value="/viewprojects")
	public String viewproj(Model model){
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
		} else {
			username = principal.toString();
		}
		User thisuser=userRepo.getUser(username);
		model.addAttribute("myprojs", userRepo.myprojects(thisuser.getId()));
		return "viewprojects";
	}
	@RequestMapping(value="viewprojects/alloc/{projid}")
	public ModelAndView assignproj(@PathVariable long projid,Model model){
		System.out.println(projid);
		System.out.println("reached here 9999999999999999999");
		return new ModelAndView("assignproj","projform",new assignprojform());
	}
	@RequestMapping(value="viewprojects/alloc/{projid}",method=RequestMethod.POST)
	public String assignproj(@PathVariable long projid,@Valid @ModelAttribute("projform")assignprojform a,
	BindingResult result, Model model){
		userRepo.assignproj(projid,a);

		
		// return "studsonproj";
		return "redirect:/viewprojects";
	}
	@RequestMapping(value="viewprojects/{projid}")
	public String viewallprojs(@PathVariable long projid, Model model){
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
		} else {
			username = principal.toString();
		}
		User thisuser=userRepo.getUser(username);
		
		model.addAttribute("workingstudents", userRepo.wokingstuds(projid));
		return "studsonproj";
	}
	@RequestMapping(value="viewprojects/{projid}/{sid}")
	public ModelAndView assignprojmarks(@PathVariable long projid,@PathVariable long sid,Model model){
		System.out.println(sid);
		System.out.println(projid);
		// System.out.println("reached here kdksndkskkkskd");
		model.addAttribute("projid", projid);
		model.addAttribute("sid", sid);
		return new ModelAndView("assignprojmarks","projgradeform",new projgradeform());
	}
	@RequestMapping(value="/viewprojects/{projid}/{sid}",method=RequestMethod.POST)
	public String assignprojmarks2(@PathVariable long projid,@PathVariable long sid,@Valid @ModelAttribute("projgradeform")projgradeform a,
	BindingResult result, ModelMap model){
		// userRepo.assignprojmarks(projid,sid,a);
		userRepo.assignprojmarks(projid, sid, a);
		return "home";
	}

	@RequestMapping(value="/getfees")
	public String getfees(Model model){
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
		} else {
			username = principal.toString();
		}
		User thisuser=userRepo.getUser(username);
		model.addAttribute("feesdetails", userRepo.getfees(thisuser.getId()));
		model.addAttribute("hostelfees",userRepo.gethostelfees(thisuser.getId()));
		return "viewfees";
	}

	@RequestMapping(value="/stafflist")
	public String stafflist(Model model){
		model.addAttribute("stafflist", userRepo.getstafflist() );
		return "staffret";
	}

}
