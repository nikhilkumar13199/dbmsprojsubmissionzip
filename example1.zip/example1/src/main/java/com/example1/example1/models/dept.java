package com.example1.example1.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class dept{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int deptid;

    private String name,address,about;
    @Column(columnDefinition="bigint default null")
    private long hod;
    @Column(columnDefinition="int default null")
    private int foundingyear;


    public int getDeptid() {
        return this.deptid;
    }

    public void setDeptid(int deptid) {
        this.deptid = deptid;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAbout() {
        return this.about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public long getHod() {
        return this.hod;
    }

    public void setHod(long hod) {
        this.hod = hod;
    }

    public int getFoundingyear() {
        return this.foundingyear;
    }

    public void setFoundingyear(int foundingyear) {
        this.foundingyear = foundingyear;
    }

    

    

    
}