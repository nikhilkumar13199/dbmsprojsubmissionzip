package com.example1.example1.forms;

public class assignprojform{
    public long sid;
    public long sem;
    public long year;
    

    public long getSid() {
        return this.sid;
    }

    public void setSid(long sid) {
        this.sid = sid;
    }

    public long getSem() {
        return this.sem;
    }

    public void setSem(long sem) {
        this.sem = sem;
    }

    public long getYear() {
        return this.year;
    }

    public void setYear(long year) {
        this.year = year;
    }

}