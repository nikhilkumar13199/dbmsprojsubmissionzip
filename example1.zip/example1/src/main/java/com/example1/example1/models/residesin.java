package com.example1.example1.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@IdClass(residesinID.class)
public class residesin{
    @Id
    private int roomno;
    @Id
    private int hostelid;
    @Id
    private long sid;


    public int getRoomno() {
        return this.roomno;
    }

    public void setRoomno(int roomno) {
        this.roomno = roomno;
    }

    public int getHostelid() {
        return this.hostelid;
    }

    public void setHostelid(int hostelid) {
        this.hostelid = hostelid;
    }

    public long getSid() {
        return this.sid;
    }

    public void setSid(long sid) {
        this.sid = sid;
    }

    public residesin(int roomno, int hostelid, long sid) {
        this.roomno = roomno;
        this.hostelid = hostelid;
        this.sid = sid;
    }

    @Override
    public String toString() {
        return "{" +
            " roomno='" + getRoomno() + "'" +
            ", hostelid='" + getHostelid() + "'" +
            ", sid='" + getSid() + "'" +
            "}";
    }

}