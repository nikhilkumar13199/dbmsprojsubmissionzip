package com.example1.example1.secureapp;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
@Service
public class MyUserDetailsService implements UserDetailsService {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	private Userrepo repo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		// change to sql query

		

 
        // String sql="insert into user values(?,?,?)";
        // int result=jdbcTemplate.update(sql);
		// String sql2="select username from user where user.username=username";

		User user = repo.getUser(username);
		if(user==null)
			throw new UsernameNotFoundException("User 404");
		
		return new UserPrincipal(user);
	}

}
