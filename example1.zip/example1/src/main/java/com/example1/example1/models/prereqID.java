package com.example1.example1.models;

import java.io.Serializable;
import java.util.Objects;

public class prereqID implements Serializable{
    private int thiscc,prereqcc;

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof prereqID)) {
            return false;
        }
        prereqID prereqID = (prereqID) o;
        return thiscc == prereqID.thiscc && prereqcc == prereqID.prereqcc;
    }

    @Override
    public int hashCode() {
        return Objects.hash(thiscc, prereqcc);
    }

}