package com.example1.example1.models;

import java.io.Serializable;
import java.util.Objects;

public class enrollmentID implements Serializable{
    private int code;
    private int year;
    private int sem;
    private long sid;


    public enrollmentID(int code, int year, int sem, int sid) {
        this.code = code;
        this.year = year;
        this.sem = sem;
        this.sid = sid;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof enrollmentID)) {
            return false;
        }
        enrollmentID enrollmentID = (enrollmentID) o;
        return code == enrollmentID.code && year == enrollmentID.year && sem == enrollmentID.sem && sid == enrollmentID.sid;
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, year, sem, sid);
    }



    
    

}