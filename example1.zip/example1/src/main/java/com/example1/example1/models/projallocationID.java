package com.example1.example1.models;

import java.io.Serializable;
import java.util.Objects;

public class projallocationID implements Serializable{
    private long projid;
    private long sid;
    private int year;
    private int sem;
    

    public projallocationID(long projid, long sid, int year, int sem) {
        this.projid = projid;
        this.sid = sid;
        this.year = year;
        this.sem = sem;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof projallocationID)) {
            return false;
        }
        projallocationID projallocationID = (projallocationID) o;
        return projid == projallocationID.projid && sid == projallocationID.sid && year == projallocationID.year && sem == projallocationID.sem;
    }

    @Override
    public int hashCode() {
        return Objects.hash(projid, sid, year, sem);
    }


}