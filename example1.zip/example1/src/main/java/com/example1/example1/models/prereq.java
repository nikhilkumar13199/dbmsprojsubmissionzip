package com.example1.example1.models;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Entity
@IdClass(prereqID.class)
public class prereq{
    @Id
    private int thiscc;
    @Id
    private int prereqcc;


    public int getThiscc() {
        return this.thiscc;
    }

    public void setThiscc(int thiscc) {
        this.thiscc = thiscc;
    }

    public int getPrereqcc() {
        return this.prereqcc;
    }

    public void setPrereqcc(int prereqcc) {
        this.prereqcc = prereqcc;
    }

}