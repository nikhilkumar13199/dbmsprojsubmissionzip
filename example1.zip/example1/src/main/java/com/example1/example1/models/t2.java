package com.example1.example1.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name="applicant")
public class t2{
    @Id 
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long id;


    // @OneToOne(mappedBy="rollno")
    // private application application;

    // private int eemarks,year,boardmarks;
    @Column(columnDefinition="int default null")
    private int eemarks;
    @Column(columnDefinition="int default null")
    private int year;
    @Column(columnDefinition="int default null")
    private int boardmarks;

    @Size(min=1,max=255,message="Please enter string of lenght between 1 and 255")
    private String name;

    private String city;
    private String fathername;
    private String email;

    @Column(columnDefinition="int default null")
    private long userid;

    public long getUserid(){
        return this.userid;
    }

    public void setUserid(long userid){
        this.userid=userid;
    }

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    

    public int getEemarks() {
        return this.eemarks;
    }

    public void setEemarks(int eemarks) {
        this.eemarks = eemarks;
    }

    public int getYear() {
        return this.year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getBoardmarks() {
        return this.boardmarks;
    }

    public void setBoardmarks(int boardmarks) {
        this.boardmarks = boardmarks;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return this.city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getFathername() {
        return this.fathername;
    }

    public void setFathername(String fathername) {
        this.fathername = fathername;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // public t2(long id, t1 student, int eemarks, int year, int boardmarks, String name, String city, String fathername, String email) {
    //     this.id = id;
    //     this.student = student;
    //     this.eemarks = eemarks;
    //     this.year = year;
    //     this.boardmarks = boardmarks;
    //     this.name = name;
    //     this.city = city;
    //     this.fathername = fathername;
    //     this.email = email;
    // }

    
    
}