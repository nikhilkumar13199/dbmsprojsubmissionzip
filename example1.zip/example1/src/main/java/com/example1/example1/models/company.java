package com.example1.example1.models;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name="company")
public class company{
    @Id 
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="companyid")
    private long id;
    
    // @Column
    @Size(min=1,max=255,message="Please enter string of lenght between 1 and 255")
    private String name;

    @Column
    private long ctc;
    @Column
    private String tentativeloc;
    @Column
    private String profile;
    @Column
    private int openings;
    @Column
    private int year;


    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getCtc() {
        return this.ctc;
    }

    public void setCtc(long ctc) {
        this.ctc = ctc;
    }

    public String getTentativeloc() {
        return this.tentativeloc;
    }

    public void setTentativeloc(String tentativeloc) {
        this.tentativeloc = tentativeloc;
    }

    public String getProfile() {
        return this.profile;
    }

    public void setProfile(String profile) {
        this.profile = profile;
    }

    public int getOpenings() {
        return this.openings;
    }

    public void setOpenings(int openings) {
        this.openings = openings;
    }

    public int getYear() {
        return this.year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public company(long id, String name, long ctc, String tentativeloc, String profile, int openings, int year) {
        this.id = id;
        this.name = name;
        this.ctc = ctc;
        this.tentativeloc = tentativeloc;
        this.profile = profile;
        this.openings = openings;
        this.year = year;
    }

    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            ", name='" + getName() + "'" +
            ", ctc='" + getCtc() + "'" +
            ", tentativeloc='" + getTentativeloc() + "'" +
            ", profile='" + getProfile() + "'" +
            ", openings='" + getOpenings() + "'" +
            ", year='" + getYear() + "'" +
            "}";
    }

}