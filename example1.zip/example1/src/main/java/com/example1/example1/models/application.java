package com.example1.example1.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="application")
public class application{
    @Id
    @Column
    private long applicantrollno;
    @Column
    private int alloteddept;
    @Column
    private Date dateofapplication;
    

    public long getApplicantrollno() {
        return this.applicantrollno;
    }

    public void setApplicantrollno(long applicantrollno) {
        this.applicantrollno = applicantrollno;
    }

    public int getAlloteddept() {
        return this.alloteddept;
    }

    public void setAlloteddept(int alloteddept) {
        this.alloteddept = alloteddept;
    }

    public Date getDateofapplication() {
        return this.dateofapplication;
    }

    public void setDateofapplication(Date dateofapplication) {
        this.dateofapplication = dateofapplication;
    }

    public application(long applicantrollno, int alloteddept, Date dateofapplication) {
        this.applicantrollno = applicantrollno;
        this.alloteddept = alloteddept;
        this.dateofapplication = dateofapplication;
    }


    @Override
    public String toString() {
        return "{" +
            " applicantrollno='" + getApplicantrollno() + "'" +
            ", alloteddept='" + getAlloteddept() + "'" +
            ", dateofapplication='" + getDateofapplication() + "'" +
            "}";
    }
    
}