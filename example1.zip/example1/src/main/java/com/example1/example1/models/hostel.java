package com.example1.example1.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GenerationType;
@Entity
@Table(name="Hostel")
public class hostel{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="hostelid")
    private long hostelid;
    @Column
    private int capacity;
    @Column
    private long fees;
    @Column
    private String name;
    @Column
    private String address;
    @Column(columnDefinition="int default 0")
    private int occupants;


    public long getHostelid() {
        return this.hostelid;
    }

    public void setHostelid(long hostelid) {
        this.hostelid = hostelid;
    }

    public int getCapacity() {
        return this.capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public long getFees() {
        return this.fees;
    }

    public void setFees(long fees) {
        this.fees = fees;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getOccupants() {
        return this.occupants;
    }

    public void setOccupants(int occupants) {
        this.occupants = occupants;
    }

    

    
}