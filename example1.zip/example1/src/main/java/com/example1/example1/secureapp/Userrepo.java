package com.example1.example1.secureapp;

import org.springframework.jdbc.core.BeanPropertyRowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import com.example1.example1.forms.admitstudform;
import com.example1.example1.forms.assignprojform;
import com.example1.example1.forms.marksform;
import com.example1.example1.forms.projgradeform;
import com.example1.example1.forms.registerincourse;
import com.example1.example1.models.complaint;
import com.example1.example1.models.course;
import com.example1.example1.models.dept;
import com.example1.example1.models.enrollment;
import com.example1.example1.models.hostel;
import com.example1.example1.models.project;
import com.example1.example1.models.staff;
import com.example1.example1.models.t1;
import com.example1.example1.models.t2;
import com.example1.example1.models.teaches;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

@Repository
public class Userrepo{

    // we are autowiring jdbc template,
    // using the properties we have configured spring automatically
    // detects and creates jdbc template using the configuration
    @Autowired
    JdbcTemplate jdbcTemplate;


    public void addUser(User u)
    {
        if(u.getRole()>3 || u.getRole()<0){
            System.out.println("Invalid user role");
            return;
        }
        String sql="insert into user(password,username,role) values(?,?,?)";
        int result=jdbcTemplate.update(sql,u.getPassword(),u.getUsername(),u.getRole());
    }

    

    public void addapplicantinfo(t2 a){
        String sql="update applicant set boardmarks=?, city=?, eemarks=?, email=?, fathername=?, name=?, year=? where userid=?;";
        
        int result=jdbcTemplate.update(sql, a.getBoardmarks(),a.getCity(),a.getEemarks(),a.getEmail(),a.getFathername(),
                                    a.getName(),a.getYear(),a.getUserid());
    }
    
    public void addstaffinfo(staff a){
        String sql="update staff set age=?, dept=?, gender=?, name=?, reportsto=? where userid=?;";
        System.out.println(a.getUserid());
        int result=jdbcTemplate.update(sql,a.getAge(),a.getDept(),a.getGender(),a.getName(),a.getReportsto(),a.getUserid());
    }

	public User getUser(String username) {
		String sql = "SELECT * FROM user WHERE username='"+username+"'";
		return jdbcTemplate.query(sql,new ResultSetExtractor<User>() {
		
		public User extractData(ResultSet rs) throws SQLException,DataAccessException{
			if(rs.next()) {
                User user = new User();
                user.setId(rs.getInt(1));
				user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setRole(rs.getInt("role"));
				return user;
			}
			return null;
		}
	});
    }

    public void admitstudent(admitstudform details){
        String f1="select * from applicant where id="+details.getAid();
        List<t2> apps=jdbcTemplate.query(f1,new BeanPropertyRowMapper(enrollment.class));
        if(apps.size()==0){
            return;
        }
        
        String sql="insert into student(userid,name) select userid,name from applicant where id=?";
        int res1=jdbcTemplate.update(sql,details.getAid());
        String sql2="update student set dept=? where userid in ( select userid from applicant where id=?)";
        int res2=jdbcTemplate.update(sql2,details.getDept(),details.getAid());
        String sql3="update user set role=1 where id in ( select userid from applicant where id=?)";
        int res3=jdbcTemplate.update(sql3,details.getAid());
        String s1="select sid from student where userid in (select userid from applicant where id="+(details.getAid())+")";
        int newid=jdbcTemplate.queryForObject(s1,Integer.class);
        System.out.println(newid);
        String s2="select hostelid from hostel where capacity-occupants>0 limit 1";
        int hid=jdbcTemplate.queryForObject(s2,Integer.class);
        System.out.println(hid);
        String s3="select occupants from hostel where hostelid="+hid;
        int roomno=jdbcTemplate.queryForObject(s3,Integer.class);
        System.out.println(roomno);
        String s4="insert into residesin values(?,?,?)";
        int res4=jdbcTemplate.update(s4,hid,roomno+1,newid);
        String s5="update hostel set occupants=? where hostelid=?";
        int res5=jdbcTemplate.update(s5,roomno+1,hid);
        
    }
    public void addcourse(course c){
        String sql="insert into course(dept,fees,name,semoffered) values(?,?,?,?)";
        int r=jdbcTemplate.update(sql, c.getDept(),c.getFees(),c.getName(),c.getSemoffered());
    }
    public void coursereg(registerincourse x,long userid, int role){
        if(role==1){
            String sql="select sid from student where userid=?";
            long xy= jdbcTemplate.queryForObject(sql, new Object[]{userid}, Integer.class);
            // System.out.println("holee");
            System.out.println(xy);
            sql="insert into enrollment(code,sem,sid,year) values(?,?,?,?)";
            int  r=jdbcTemplate.update(sql, x.getCode(),x.getSem(),xy,x.getYear());
        }
        
    }
    public void addTeachesInstance(teaches x){
        String sql="insert into teaches values(?,?,?,?,?,?)";
        int r=jdbcTemplate.update(sql,x.getCoursecode(),x.getEmpid(),x.getSectionno(),x.getSem(),x.getYear(),x.getClassroom());
    }

    public List<enrollment> findenr(long userid){
        String sql="select sid,code from enrollment where code in ( select coursecode from teaches where empid in ( select empid from staff where userid=?) );";
        List<enrollment> enrs=jdbcTemplate.query(sql,new BeanPropertyRowMapper(enrollment.class),userid);
        return enrs;

    }



	public List<teaches> findAllCourses(long id) {
        String sql="select coursecode from teaches where empid in (select empid from staff where userid=?)";
        List<teaches> courses=jdbcTemplate.query(sql,new BeanPropertyRowMapper(teaches.class),id);
        return courses;
    }
    
    public Object findAllStudetsEnr(long code){
        String sql="select sid,year,sem from enrollment where code=?";
        List<enrollment> studsenr=jdbcTemplate.query(sql,new BeanPropertyRowMapper(enrollment.class),code);
        return studsenr;
    }



	public void assignmarks(int courseid, long sid,  marksform a) {
        String sql="update enrollment set midsem=?,endsem=?,grade=?,attendance=? where code=? and sid=? ";
        int r=jdbcTemplate.update(sql,a.getMidsem(),a.getEndsem(),a.getGrade(),a.getAttendance(),courseid,sid);
	}



	public void addhostel(@Valid hostel a) {
        String sql="insert into hostel(address,capacity,fees,name) values(?,?,?,?)";
        int r=jdbcTemplate.update(sql,a.getAddress(),a.getCapacity(),a.getFees(),a.getName());
	}



	public void addproj(@Valid project a,long userid) {
        String s1="select empid from staff where userid="+userid;
        int empid=jdbcTemplate.queryForObject(s1,Integer.class);
        String s2="select dept from staff where userid="+userid;
        int dept=jdbcTemplate.queryForObject(s2,Integer.class);
        String sql="insert into project(name,stipend,guideempid,dept) values(?,?,?,?)";
        int r=jdbcTemplate.update(sql,a.getName(),a.getStipend(),empid,dept);
	}



	public void addcomp(long id, @Valid complaint a) {
        String s1="select sid from student where userid="+id;
        int sid=jdbcTemplate.queryForObject(s1,Integer.class);
        System.out.println(sid);
        s1="select roomno from residesin where sid="+sid;
        int roomno=jdbcTemplate.queryForObject(s1,Integer.class);
        System.out.println(roomno);
        s1="select hostelid from residesin where sid="+sid;
        int hid=jdbcTemplate.queryForObject(s1,Integer.class);
        
        String sql="insert into complaint(hostelid,roomno,sid,subject) values(?,?,?,?)";
        int r=jdbcTemplate.update(sql,hid,roomno,sid,a.getSubject());
	}
    
    public List<complaint> findallcomps() {
        // String sql="select coursecode from teaches where empid in (select empid from staff where userid=?)";
        String sql="select * from complaint";
        List<complaint> comps=jdbcTemplate.query(sql,new BeanPropertyRowMapper(complaint.class));
        System.out.println("complaints found");
        System.out.println(comps.size());
        return comps;
    }



	public void changecompstatus(long complaintid) {
        String sql="update complaint set status='Resolved' where complaintid=?";
        int r=jdbcTemplate.update(sql,complaintid);
	}



	public Object getresult(long userid) {
        String s1="select sid from student where userid="+userid;
        int sid=jdbcTemplate.queryForObject(s1,Integer.class);
        String s2="select * from enrollment where sid="+sid+" order by year";
        List<enrollment> res=jdbcTemplate.query(s2,new BeanPropertyRowMapper(enrollment.class));
        return res;

    }
    
    public Object myprojects(long id){
        String s1="select empid from staff where userid="+id;
        int empid=jdbcTemplate.queryForObject(s1,Integer.class);
        String sql="select * from project where guideempid="+empid;
        System.out.println(id);
        List<project> myprojs=jdbcTemplate.query(sql,new BeanPropertyRowMapper(project.class));
        System.out.println(myprojs.size());
        return myprojs;
    }



	public void assignproj(long projid, @Valid assignprojform a) {
        String sql="insert into projectallocation(projid,sem,sid,year) values(?,?,?,?)";
        int r=jdbcTemplate.update(sql,projid,a.getSem(),a.getSid(),a.getYear());
        System.out.println("assignproj is working");
	}



	public Object wokingstuds(long projid) {
        System.out.println(projid);
        String sql="select student.name,student.sid as sid from student,projectallocation where student.sid=projectallocation.sid and projid="+projid;
        List<t1> x=jdbcTemplate.query(sql,new BeanPropertyRowMapper(t1.class));
        System.out.println(x.size());
		return x;
	}



	public void assignprojmarks(long projid, long sid, @Valid projgradeform a) {
        String sql="update projectallocation set grade=?,status=? where projid=? and sid=?";
        int r=jdbcTemplate.update(sql,a.getGrade(),a.getStatus(),projid,sid);
	}



	public Object getfees(long id) {
        String sql="select sum(fees) from course where code in (select code from enrollment where sid in (select sid from student where userid="+id+"))";
        long fees=jdbcTemplate.queryForObject(sql,Long.class);
        System.out.println(fees);
        
        return fees;
	}

    public Object gethostelfees(long id){
        String sql="select fees from hostel,residesin where hostel.hostelid=residesin.hostelid and sid in (select sid from student where userid="+id+")";
        long hostelfees=jdbcTemplate.queryForObject(sql,Long.class);
        return hostelfees;
    }



	public Object getstafflist() {
        String sql="select empid as id,age,attendance,dept,name,gender,reportsto,userid from staff";
        List<staff> x=jdbcTemplate.query(sql,new BeanPropertyRowMapper(staff.class));
        return x;
	}



	public List<t2> getallApps() {
        String sql="select id,name from applicant where userid not in (select userid from student)";
        List<t2> x=jdbcTemplate.query(sql,new BeanPropertyRowMapper(t2.class));
		return x;
	}


    public List<dept> getalldept(){
        String sql="select deptid,name from dept";
        List<dept> x=jdbcTemplate.query(sql,new BeanPropertyRowMapper(dept.class) );
        return x;
    }



	public List<t1> findallstudents() {
        String sql="select * from student";
        List<t1> x=jdbcTemplate.query(sql,new BeanPropertyRowMapper(t1.class));
        System.out.println(x.size());
        for(t1 j:x){
            System.out.println(j.getSid());
            System.out.println(j.getName());
        }
		return x;
	}



	
    


}
