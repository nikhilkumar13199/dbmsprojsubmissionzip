package com.example1.example1.controllers;

import com.example1.example1.secureapp.Userrepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class example1Controller{

    // private t1repository t1repo;
    // private staffret staffrepo;

    // public example1Controller(t1repository t1Repo, staffret staffrepo){
    //     this.t1repo=t1Repo;
    //     this.staffrepo=staffrepo;
    // }
        @Autowired
        Userrepo userRepo;

    
    @GetMapping("/")
    public String showIndex(Model model){
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
		} else {
			username = principal.toString();
        }
        System.out.println(username);
        model.addAttribute("username",username);
        model.addAttribute("t1list", userRepo.findallstudents()); 
        return "index";
    }


    // @GetMapping("/acadfee")
    // public String acadfee(Model model){
    //     model.addAttribute("thisacadfee", );
    //     return "acadfee";
    // }

    
    
}