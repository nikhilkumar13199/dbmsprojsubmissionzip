package com.example1.example1.forms;

public class registerincourse{
    private long code;
    private int year;
    private int sem;


    public long getCode() {
        return this.code;
    }

    public void setCode(long code) {
        this.code = code;
    }

    public int getYear() {
        return this.year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getSem() {
        return this.sem;
    }

    public void setSem(int sem) {
        this.sem = sem;
    }


}