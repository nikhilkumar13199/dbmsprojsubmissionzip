// package com.example1.example1.repositories;

// import com.example1.example1.models.t1;

// import org.springframework.data.jpa.repository.Query;
// import org.springframework.data.repository.CrudRepository;
// import org.springframework.stereotype.Repository;


// import java.util.List;
// import java.util.Optional;
// @Repository
// public interface t1repository extends CrudRepository<t1,Long>{

    

//     List<t1> findAll(); 
//     Optional<t1> findById(Long id);

//     // @Query("select sum(fees) from course where code in ( select code from enrollment where sid in (select sid from student where userid=?) )")
    
    
    
// }