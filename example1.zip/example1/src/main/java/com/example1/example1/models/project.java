package com.example1.example1.models;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="project")
public class project{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column
    private long id;
    @Column
    private long dept;
    @Column
    private Date dateofsubmission;
    @Column
    private long stipend;
    @Column
    private String name;
    @Column
    private long guideempid;

    
    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getDept() {
        return this.dept;
    }

    public void setDept(long dept) {
        this.dept = dept;
    }

    public Date getDateofsubmission() {
        return this.dateofsubmission;
    }

    public void setDateofsubmission(Date dateofsubmission) {
        this.dateofsubmission = dateofsubmission;
    }

    public long getStipend() {
        return this.stipend;
    }

    public void setStipend(long stipend) {
        this.stipend = stipend;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getGuideempid() {
        return this.guideempid;
    }

    public void setGuideempid(long guideempid) {
        this.guideempid = guideempid;
    }

    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            ", dept='" + getDept() + "'" +
            ", dateofsubmission='" + getDateofsubmission() + "'" +
            ", stipend='" + getStipend() + "'" +
            ", name='" + getName() + "'" +
            ", guideempid='" + getGuideempid() + "'" +
            "}";
    }



}